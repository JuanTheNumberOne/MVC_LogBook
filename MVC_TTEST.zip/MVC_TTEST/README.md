# MVC_LogBook

This is my first web application. It is aimed to display a filtered search of an SQL table that contains a record of the user's performed
actions, mainly changing process values in an automated production line, enabling options and so on. The part that registers the actions
is written in VBS script in a TIA Portal Project (SIEMENS - WINCC (Visualization) + STEP 7 (PLC Logic)). 

This app was developed to try to 
display in a more refined way the data stored in the database, since the tools offered by TIA PORTAL to create views are somewhat limited
(lack of dynamic tables, archaic style). Although it is my first web app and I am a rookie, if there is any suggestion, idea, criticism
that would result in an improvement to the app and/or my "coding" skills and knowledge, fire at will! :D

